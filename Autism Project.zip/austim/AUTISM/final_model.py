# Import necessary libraries
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

import warnings

# Filter the unnecessary warnings
warnings.filterwarnings("ignore")

# Load the dataset
df1 = pd.read_csv('Autism.csv')

# Create a new DataFrame with selected columns
df = pd.DataFrame()
df = pd.DataFrame()
df['Age'] = df1['Age']
df['Sex'] = df1['Sex']
df['ADHD'] = df1['ADHD']
df['anxiety'] = df1['anxiety']
df['epilepsy'] = df1['epilepsy']
df['CARS'] = df1['CARS']
df['SRS'] = df1['SRS']
df['WISC'] = df1['WISC']
df['ABA'] = df1['ABA']
df['Asq'] = df1['Asq']
df['Jaundice'] = df1['Jaundice']  # Corrected spelling from 'Jauundice'
df['Family_ASD'] = df1['Family_ASD']
df['Result'] = df1['Result']

df['Result'] = df['Result'].map({0: 0, 1: 1})

# Handle NaN values in 'Result' column
if df['Result'].isnull().any():
    # Drop rows with NaN in 'Result'
    df = df.dropna(subset=['Result'])

# Encode the 'City' column


# Save the LabelEncoder for Flask app use


# Split the data into features and target
X = df.drop("Result", axis=1).values
y = df["Result"].values

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=101)

# Initialize a list to track error rates
error = []

# Determine the optimal number of estimators
for i in range(550, 600):
    rfc = RandomForestClassifier(n_estimators=i)
    rfc.fit(X_train, y_train)
    pred_i = rfc.predict(X_test)
    error.append(np.mean(pred_i != y_test))

# Fit the model with the optimal number of estimators
optimal_estimators = 571  # You can change this based on error analysis
rfc = RandomForestClassifier(n_estimators=optimal_estimators)
rfc.fit(X_train, y_train)

# Save the model
pickle.dump(rfc, open('autism.pkl', 'wb'))

# Optional: Verify by reloading the model and label encoder
model = pickle.load(open('autism.pkl', 'rb'))


# Confirmation
print("Model and LabelEncoder saved successfully!")
